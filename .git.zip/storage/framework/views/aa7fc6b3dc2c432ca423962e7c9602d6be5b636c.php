

<?php $__env->startSection('container'); ?>

<center>
    <br>
    <hr class="navbar-divider">
    <label class="label">Tabel Produksi</label>
    <hr class="navbar-divider">
    <br>
</center>

<div class="mb-5">
    <a href="/production/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Tambah Produksi</a>
</div>

<?php if(session('succes')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('succes')); ?>

    </div>
    <script>
        alert('succes');
    </script>
<?php endif; ?>

<table class="table-auto">
    <thead>
        <tr>
            <th class="border px-4 py-2">Name</th>
            <th class="border px-4 py-2">Description</th>
            <th class="border px-4 py-2">Projected End Date</th>
            <th class="border px-4 py-2">Projected Output Quantity</th>
            <th class="border px-4 py-2">Actual Output Quantity</th>
            <th class="border px-4 py-2">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($production->production_name); ?></td>
                <td class="border px-4 py-2"><?php echo e($production->production_description); ?></td>
                <td class="border px-4 py-2"><?php echo e($production->production_projected_end_date); ?></td>
                <td class="border px-4 py-2"> <?php $__currentLoopData = $production->process; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                    <?php if(in_array($pp->process_type,[1])): ?>
                        <?php $__currentLoopData = $pp->processMaterial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li>  <?php echo e($ppm->process_material_name); ?> / <?php echo e($ppm->process_material_quantity); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                <td class="border px-4 py-2"> <?php $__currentLoopData = $production->process; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                    <?php if(in_array($pp->process_type,[5])): ?>
                        <?php $__currentLoopData = $pp->processMaterial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li>  <?php echo e($ppm->process_material_name); ?> / <?php echo e($ppm->process_material_quantity); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                <td class="border px-4 py-2">
                    <a href="/production/<?php echo e($production->id); ?>" class="bg-green-500 text-white p-2">Detail</a>
                    <a href="/production/<?php echo e($production->id); ?>/edit" class="bg-blue-500 text-white p-2">Edit</a>
                    <form action="/production/<?php echo e($production->id); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 text-white p-2">Delete</button>
                    </form>
               
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/production/indexProduction.blade.php ENDPATH**/ ?>
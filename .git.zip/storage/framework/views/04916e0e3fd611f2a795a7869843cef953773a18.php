
<?php $__env->startSection('container'); ?>
    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Edit Form Material</label>
        <hr class="navbar-divider">
        <br>
    </center>

    <form action="/material/<?php echo e($material->id); ?>" method="POST" id="createMaterial" class="flex flex-col m-12">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label class="label">Material Name</label>
            <div class="control">
                <input class="input" type="text" name="name" id="name" value="<?php echo e($material->material_name); ?>">
            </div>
        <label class="label">Material Description</label>
            <div class="control">
              <textarea class="textarea" name="description" id="description"><?php echo e($material->material_description); ?></textarea>
            </div>
        <label class="label">Material Quantity</label>
        <div>
            <input type="number" name="quantity" id="quantity" class="input" value="<?php echo e($material->material_quantity); ?>">
            
        </div>
        <label class="label">Material Measures</label>
        <select name="measure_unit" id="measure_unit" class="input">
                <option value="kg" <?php echo e($material->material_measure_unit == 'kg' ? 'selected' : ''); ?>>kg</option>
                <option value="l" <?php echo e($material->material_measure_unit == 'l' ? 'selected' : ''); ?>>l</option>
                <option value="m" <?php echo e($material->material_measure_unit == 'm' ? 'selected' : ''); ?>>m</option>
                <option value="piece" <?php echo e($material->material_measure_unit == 'piece' ? 'selected' : ''); ?>>piece</option>
            </select>
            <!--<div class="control">-->
            <!--  <div class="select" name="type" id="type">-->
            <!--    <select>-->
            <!--        <<option value="Raw Material" <?php echo e($material->material_type == 'Raw Material' ? 'selected' : ''); ?>>Raw</option>-->
            <!--        <option value="Finished" <?php echo e($material->material_type == 'Finished' ? 'selected' : ''); ?>>Finished</option>-->
            <!--    </select>-->
            <!--  </div>-->
            <!--</div>-->
        <br>
        <button type="submit" class="button green">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/material/editMaterial.blade.php ENDPATH**/ ?>

<?php $__env->startSection('container'); ?>

    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Tabel Material</label>
        <hr class="navbar-divider">
        <br>
    </center>
    <div class="mb-5">
        <a href="/material/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Tambah Material</a>
    </div>
 
    <?php if(session('succes')): ?>
        <div class="bg-green-500 text-black p-2">
            <?php echo e(session('succes')); ?>

        </div>
        <script>
            alert('succes');
        </script>
        
    <?php endif; ?>
    <table class="table-auto">
        <thead>
            <tr>
                <th class="border px-4 py-2">Name</th>
                <th class="border px-4 py-2">Description</th>
                <th class="border px-4 py-2">Quantity</th>
                <th class="border px-4 py-2">Type</th>
                <th class="border px-4 py-2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($material->material_name); ?></td>
                    <td class="border px-4 py-2"><?php echo e($material->material_description); ?></td>
                    <td class="border px-4 py-2"><?php echo e($material->material_quantity); ?> <?php echo e($material->material_measure_unit); ?></td>
                    <td class="border px-4 py-2"><?php echo e($material->material_type); ?></td>
                    <td class="border px-4 py-2">
                        <a href="/material/<?php echo e($material->id); ?>/edit" class="bg-blue-500 text-white p-2">Edit</a>
                        <form action="/material/<?php echo e($material->id); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white p-2">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if(session()->has('success')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('success')); ?>

    </div>
    <script>
        alert('succes');
    </script>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/material/indexMaterial.blade.php ENDPATH**/ ?>
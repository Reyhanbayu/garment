
<?php $__env->startSection('container'); ?>

    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Tabel Material</label>
        <hr class="navbar-divider">
        <br>
    </center>
    <div class="mb-5 flex flex-row justify-between">
        <div class="flex flex-row w-1/3">
            <select name="category" id="selectType" class=" border border-gray-400 p-2">
                <option value="0" selected>Select to filter by Category...</option>
                <?php $__currentLoopData = $materialCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    
            <select name="type" id="selectSubType" class="border border-gray-400 p-2" disabled>
                <option value="0">Please select category first</option>
            </select>
            <input type="text" name="search" id="search" class="border border-gray-400 p-2" placeholder="Search by name...">
            
        </div>
        
        <a href="/material/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Tambah Material</a>
        
    </div>

    <div>
        
        
    </div>
 
    <?php if(session('succes')): ?>
        <div class="bg-green-500 text-black p-2">
            <?php echo e(session('succes')); ?>

        </div>
        <script>
            alert('succes');
        </script>
        
    <?php endif; ?>
    <table class="table-auto" id="materialTable">
        <thead>
            <tr>
                <th class="border px-4 py-2 w-1/4">Name</th>
                <th class="border px-4 py-2 w-1/4">Description</th>
                <th class="border px-4 py-2 w-1/4" >Quantity</th>
                <th class="border px-4 py-2 w-1/4">Action</th>
            </tr>
        </thead>
        <tbody id="materialTableBody">
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php echo e($material->material_sub_category_id); ?>">
                    <td class="border px-4 py-2"><?php echo e($material->material_name); ?></td>
                    <td class="border px-4 py-2"><?php echo e($material->material_description); ?></td>
                    <td class="border px-4 py-2"><?php echo e($material->material_quantity); ?> <?php echo e($material->material_measure_unit); ?></td>
                    
                    <td class="border px-4 py-2">
                        <a href="/material/<?php echo e($material->id); ?>" class="bg-green-500 text-white p-2">History</a>
                        <a href="/material/<?php echo e($material->id); ?>/edit" class="bg-blue-500 text-white p-2">Edit</a>
                        <form action="/material/<?php echo e($material->id); ?>" method="POST" class="inline" onsubmit="return confirm('are you sure?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white p-2">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if(session()->has('success')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('success')); ?>

    </div>
    <script>
        alert('succes');
    </script>
    <?php endif; ?>

    <script src="<?php echo e(asset("js/material.js")); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/material/indexMaterial.blade.php ENDPATH**/ ?>
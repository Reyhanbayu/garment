<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('css/main.css?v=1628755089081')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('https://cdn.materialdesignicons.com/4.9.95/css/materialdesignicons.min.css')); ?>">

</head>
<body class=" p-4">
    <div class=" p-0">
        <h1>User <?php echo e($subProses->subProcess->user->name); ?></h1>
        <h2>Proses <?php echo e($subProses->subProcess->process->process_name); ?></h2>
        <table>
            <thead>
                <tr>
                    <th>Sub Process Material</th>
                    <th>Sisa Target</th>
                    <th>Selesai</th>
                    <th>Diserahkan</th>
                    <th>Updated At</th>
                </tr>
            </thead>
            <tbody>
                <tr >
                    <td class=" border border-black"><?php echo e($subProses->subProcess->processMaterial->process_material_name); ?></td>
                    <td class=" border border-black"><?php echo e($subProses->subProcess->sub_proses_projected); ?></td>
                    <td class=" border border-black"><?php echo e($subProses->subProcess->sub_proses_actual); ?></td>
                    <td class=" border border-black"><?php echo e($subProses->quantity); ?></td>
                    <td class=" border border-black"><?php echo e($subProses->subProcess->updated_at); ?></td>
                </tr>
                
            </tbody>
        </table>
        <br>
        <?php if($subProses->is_done == 1): ?>
            <h1>Sub Process Selesai dan telah dikonfirmasi</h1>
        <?php else: ?>
        <form action="/subproses/update/<?php echo e($subProses->subProcess->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="quantity" value="<?php echo e($subProses->quantity); ?>">
            <input type="hidden" name="sph_id" value="<?php echo e($subProses->id); ?>">
            <input type="hidden" name="user_id" value="<?php echo e($subProses->subProcess->user_id); ?>">
            <input type="hidden" name="process_id" value="<?php echo e($subProses->subProcess->process_id); ?>">
            <input type="hidden" name="process_material_id" value="<?php echo e($subProses->subProcess->process_material_id); ?>">
            <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Konfirmasi</button>
        
        </form>
        <?php endif; ?>
    </div>
</body>
<script src="<?php echo e(url('https://cdn.tailwindcss.com')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/main.min.js?v=1628755089081')); ?>"></script>
</html>


<?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/subproses/show.blade.php ENDPATH**/ ?>
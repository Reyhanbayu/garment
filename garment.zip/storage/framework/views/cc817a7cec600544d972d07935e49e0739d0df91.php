

<?php $__env->startSection('container'); ?>

<center>
    <br>
    <hr class="navbar-divider">
    <label class="label">Tabel Produksi</label>
    <hr class="navbar-divider">
    <br>
</center>
<div class="mb-5">
    <a href="/production/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Tambah Produksi</a>
</div>

<?php if(session('succes')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('succes')); ?>

    </div>
    <script>
        alert('succes');
    </script>
<?php endif; ?>

<table class="table-auto">
    <thead>
        <tr>
            <th class="border px-4 py-2">Name</th>
            <th class="border px-4 py-2">Description</th>
            <th class="border px-4 py-2">Status</th>
            <th class="border px-4 py-2">Projected End Date</th>
            <th class="border px-4 py-2">Output Quantity</th>
            <th class="border px-4 py-2">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($production->production_name); ?></td>
                <td class="border px-4 py-2"><?php echo e($production->production_description); ?></td>
                <td class="border px-4 py-2"><?php echo e($production->production_status); ?></td>
                <td class="border px-4 py-2"> <?php echo e($production->production_actual_end_date); ?> / <?php echo e($production->production_projected_end_date); ?></td>
                <td class="border px-4 py-2"><?php echo e($production->production_output_quantity); ?></td>
                <td class="border px-4 py-2">
                    <a href="/production/<?php echo e($production->id); ?>/edit" class="bg-blue-500 text-white p-2">Edit</a>
                    <form action="/production/<?php echo e($production->id); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 text-white p-2">Delete</button>
                    </form>
               
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/production/indexProduction.blade.php ENDPATH**/ ?>
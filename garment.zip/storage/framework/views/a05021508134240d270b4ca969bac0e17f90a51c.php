
<?php $__env->startSection('container'); ?>
    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Form Produksi</label>
        <hr class="navbar-divider">
        <br>
    </center>
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
        <script>
            alert('Please fill all the fields');
        </script>
    <?php endif; ?>
    <form action="/production" method="POST" id="createProduction" class="flex flex-col m-12">
        <?php echo csrf_field(); ?>
        <label class="label">Production Name</label>
        <input class="input" type="text" name="name" id="name" placeholder="Production Name">
        <label class="label">Production Type</label>
        <select name="production_type" id="production_type" class="border border-gray-400 p-2">
            <?php $__currentLoopData = $productionType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>"><?php echo e($type->production_type_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label class="label">Production Description</label>
        <textarea class="textarea" name="description" id="description" placeholder="Production Description"></textarea>
        <label for="end_date" class="label">Production End Date</label>
        <input type="date" name="end_date" id="end_date" class="border border-gray-400 p-2" value="<?php echo e(date('Y-m-d')); ?>">
        <div class="flex">
            <div class="label">Material</div>
            <button id="materialButton" type="button" class="bg-blue-500 p-2 mx-4">Add</button>
            <input type="hidden" name="totalMaterial" id="totalMaterial" value="1">
        </div>
        <div class="materialContainer">
            <div class="flex">
                <div class="flex flex-col">
                    <label for="input_quantity" class="label">Input Quantit Material 1</label>
                    <input type="number" name="input_quantity_1" id="input_quantity_1" class="border border-gray-400 p-2" value="0" min="0">
                </div>
                <div class="flex flex-col">
                    <label for="material_id" class="label">Material Type 1</label>
                    <select name="material_id_1" id="material_id_1" class="border border-gray-400 p-2">
                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($material->id); ?>"><?php echo e($material->material_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
            </div>
        </div>
        <label for="output_quantity" class="label">Projected Output</label>
        <div class="flex">
            <?php $__currentLoopData = $ukurans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col">
                <label for="output_quantity"><?php echo e($ukuran->name); ?></label>
                <input type="number" name="output_quantity_<?php echo e($ukuran->id); ?>" id="output_quantity_<?php echo e($ukuran->id); ?>" class="border border-gray-400 p-2" value="0" min="0">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       <br>
        <button type="submit" class="button green">Submit</button>

    </form>
    <?php if(session('succes')): ?>
        <div class="bg-green-500 text-white p-2">
            <?php echo e(session('succes')); ?>

            
        </div>
        <script>
            console.log('succes');
        </script>
    <?php endif; ?>

    <script src="<?php echo e(asset('js/production.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/production/formProduction.blade.php ENDPATH**/ ?>

<?php $__env->startSection('container'); ?>
<center>
    <br>
    <hr class="navbar-divider">
    <label class="label">Edit Production Type</label>
    <hr class="navbar-divider">
    <br>
</center>

<Form method="POST" action="/productiontype/<?php echo e($productionType->id); ?>" >
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-4">
        <label for="name" class="sr-only">Name</label>
        <input type="text" name="name" id="name" placeholder="Production Name" class="bg-gray-100 border-2 w-full p-4 rounded-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($productionType->production_type_name); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-500 mt-2 text-sm">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
        <div class="mb-4">
            <label for="role" class="sr-only">Role</label>
            <div class="flex">
                <?php $__currentLoopData = $processTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($process->id, $productionType->production_process->pluck('process_type_id')->toArray())): ?>
                        <label for="process"><?php echo e($process->process_type_name); ?></label>
                        <input type="checkbox" name="process[]" value="<?php echo e($process->id); ?>" class="bg-gray-100 border-2 w-full p-4 rounded-lg" checked>
                    <?php else: ?>
                        <label for="process"><?php echo e($process->process_type_name); ?></label>
                        <input type="checkbox" name="process[]" value="<?php echo e($process->id); ?>" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Register</button>
</Form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/productionType/edit.blade.php ENDPATH**/ ?>
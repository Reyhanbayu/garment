

<?php $__env->startSection('container'); ?>

    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Edit Form Produksi</label>
        <hr class="navbar-divider">
        <br>
    </center>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
    </div>
    <script>
        alert('Please fill all the fields');
    </script>
<?php endif; ?>

<form action="/production/<?php echo e($production->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-4">
        <label for="production_name" >Name</label>
        <input type="text" name="production_name" id="production_name" placeholder="Name" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($production->production_name); ?>">
    </div>
    <div class="mb-4">
        <label for="production_description" >Description</label>
        <input type="text" name="production_description" id="production_description" placeholder="Description" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($production->production_description); ?>">
    </div>
    
    <div class="mb-4">
    <label for="production_type" >Type</label>
    <select name="production_type" id="production_type" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
        <?php echo e($production->production_type); ?>

        <?php $__currentLoopData = $productionType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($type->id == $production->production_type): ?>
                <option value="<?php echo e($type->id); ?>" selected><?php echo e($type->production_type_name); ?></option>
            <?php else: ?>
                <option value="<?php echo e($type->id); ?>"><?php echo e($type->production_type_name); ?></option>    
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>
    
    <div class="mb-4">
        <label for="production_projected_end_date" >Projected End Date</label>
        <input type="date" name="production_projected_end_date" id="production_projected_end_date" placeholder="Projected End Date" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($production->production_projected_end_date); ?>">
    </div>
    <div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Update</button>
    </div>  
</form>

<center>
    <br><br>
    <hr class="navbar-divider">
    <label class="label">Cretae Process Form</label>
    <hr class="navbar-divider">
    <br>
</center>
<form action="/process" method="POST" >
    <?php echo csrf_field(); ?>
    <h1></h1>
    <div class="mb-4">
        <input type="hidden" name="production_id" id="production_id" value="<?php echo e($production->id); ?>">
        
        <input type="hidden" name="process_status" id="process_status" value="menunggu">
    </div>
    <div class="mb-4">
        <label for="user_id">Input id</label>
        <select name="user_id" id="user_id" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
            <?php $__currentLoopData = $person; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user[0]->user->id); ?>"><?php echo e($user[0]->user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-4">
        <input type="hidden" name="process_name" id="process_name" placeholder="Name" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="">
    </div>
    <div class="mb-4">
        <label for="process_id" >Process ID</label>
        <select id="process_id" name="process_id" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
            <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($process->process_type == 1 || $process->process_type == 5): ?>
                <?php continue; ?>
            <?php else: ?>
            <option value="<?php echo e($process->id); ?>"><?php echo e($process->process_name); ?></option>
            <?php endif; ?>
                
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    


    <div class="mb-4" id="potongOutput">
        <div>
            <label for="process_output_material_id" >Material Output</label>
            <select name="process_output_material_id" id="process_output_material_id" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
                <option value="0">Potong Baju</option>
                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($material->id); ?>"><?php echo e($material->material_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="number" name="process_output_quantity" id="process_output_quantity" placeholder="Quantity" class="flex bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e(old('process_output_quantity')); ?>">
        </div>
        <div class="hidden flex-wrap" id="ukuranBagian">
            <?php $__currentLoopData = $ukuranBagian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col">
                <h1><?php echo e($item->material_name); ?></h1>
                <input type="number" class="border border-gray-400 p-2" name="<?php echo e("process_output_bagian_".$item->id); ?>" value=0 >
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div>
        <button type="submit" id="submitProcess" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Create</button>
    </div>

</form>


<center>
    <br><br>
    <hr class="navbar-divider">
    <label class="label">Sub Process Table</label>
    <hr class="navbar-divider">
</center>
<?php $__currentLoopData = $processes->whereNotIn('process_type',[1]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <br><br>
    <h1 class=" font-bold"><?php echo e($p->process_name); ?></h1>
    <h1>Input Quantity</h1>
    <?php $__currentLoopData = $p->processMaterial->where('process_material_status','Input Produksi'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    - <?php echo e($pm->process_material_name); ?>/<?php echo e($pm->process_material_quantity); ?> 
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $p->subProses->GroupBy('user_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" border border-black">
            <h1 class="">Proses Dikerjakan oleh user <?php echo e($subGroup[0]->user->name); ?></h1>
            
            <?php $__currentLoopData = $subGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
            <form action="/subproses/<?php echo e($sp->id); ?>" method="POST">
                <div class="grid grid-cols-8 gap-6 font-bold">
                <h3>Nama Material</h3>
                <h3>Projected</h3>
                <h3>Actual</h3>
                <h3>Sisa</h3>
                <h3>Ambil</h3>
                </div>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="grid grid-cols-8 gap-6">
                    <?php echo e($sp->processMaterial->process_material_name); ?> 
                    <input type="hidden" name="user_id" value="<?php echo e($sp->user_id); ?>">
                    <input type="hidden" name="process_id" value="<?php echo e($sp->process_id); ?>">
                    <p>Target : <?php echo e($sp->sub_proses_projected); ?></p>
                    <p>Target : <?php echo e($sp->sub_proses_actual); ?></p>
                    <p>Target : <?php echo e($sp->sub_proses_projected - $sp->sub_proses_actual); ?></p>
                    <input type="number" name="quantityAmbil" id="quantityAmbil" class=" border border-black" value="0" max="<?php echo e($sp->sub_proses_projected - $sp->sub_proses_actual); ?>">
                    <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Update</button>
                    <?php if(!$sp->subProcessHistories->isEmpty()): ?>
                    <button type="button" class="bg-red-500 text-white px-4 py-3 rounded font-medium" id="button_<?php echo e($sp->id); ?>" onclick="openDetail(<?php echo e($sp->id); ?>)"  >Check Detail</button>
                    
                    
                    <?php endif; ?>
                    </form>
                    <form action="/subproses/<?php echo e($sp->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 text-white px-4 py-3 rounded font-medium">Delete</button>
                    </form>
                </div>
                <br>
                <hr class="navbar-divider">
                <?php if(!$sp->subProcessHistories->isEmpty()): ?>
                <div id="detail_<?php echo e($sp->id); ?>" class=" mb-4 hidden">
                    <h3 class="font-bold">Detail Pengambilan</h3>
                    <div class="grid grid-cols-8 gap-6">
                    
                        <h3>Quantity</h3>
                        <h3>Time</h3>
                    </div>
                    <?php $__currentLoopData = $sp->subProcessHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                        <div class="grid grid-cols-8 gap-6">
                            <p><?php echo e($history->quantity); ?></p>
                            <p><?php echo e($history->created_at); ?></p>
                            <?php if($history->is_done != 1): ?>
                            <a href="/subproses/<?php echo e($history->id); ?>" class="bg-blue-500 text-white px-4 py-3 rounded font-medium" target="_blank">Check</a>
                            <form action="/subproses/history/<?php echo e($history->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 text-white px-4 py-3 rounded font-medium">Delete</button>
                            </form>
                            <a href="/generate/<?php echo e($history->id); ?>" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Generate QR</a>
                            <button type="button" class="bg-red-500 text-white px-4 py-3 rounded font-medium" onclick="printExternal('<?php echo e('/print/'.$history->id); ?>')">Print</button>
                            <?php else: ?>
                            <a href="/subproses/<?php echo e($history->id); ?>" class="bg-blue-500 text-white px-4 py-3 rounded font-medium">Check</a>
                            <p>Telah dikonfimasi</p>
                            <?php endif; ?>
                            
                        </div>
                        <br>
                        <hr class="navbar-divider">
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
               
                
                <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<script src="<?php echo e(asset("js/process.js")); ?>"></script>

<script>
function closeDetail(id){
    let detail=document.getElementById('detail_'+id);     
    detail.classList.add("hidden");
    
    let button=document.getElementById('button_'+id);
    button.onclick = function () { openDetail(id); };
}

function openDetail(id){
    let detail=document.getElementById('detail_'+id);     
    detail.classList.remove("hidden");
    
    let button=document.getElementById('button_'+id);
    button.onclick = function () { closeDetail(id); };
}


</script>

    


<?php if(session('succes')): ?>
    <div class="bg-green-500 text-white p-2">
        <?php echo e(session('succes')); ?>

        
    </div>
    <script>
        console.log('succes');
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/production/editProduction.blade.php ENDPATH**/ ?>
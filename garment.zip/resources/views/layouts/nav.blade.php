<nav class=" h-16 bg-gray-600 w-screen ">
    <ul class=" flex h-full items-center my-auto justify-end text-xl">
        <li class=" mx-4"> <a href="/material"> Material </a></li>   
        <li class=" mx-4"> <a href="/production"> production </a></li>
        <li class=" mx-4"> <a href="/process"> Process </a></li>
    </ul>
</nav>